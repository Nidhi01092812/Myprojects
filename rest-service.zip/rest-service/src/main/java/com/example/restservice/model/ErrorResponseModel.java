package com.example.restservice.model;

import lombok.Data;

@Data
public class ErrorResponseModel {

	Status status;
	String message;
	

}
