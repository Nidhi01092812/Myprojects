package com.example.restservice.model;

import lombok.Data;

@Data
public class NumberOperationRequestModel {

    private int[] input;
       
    
}
