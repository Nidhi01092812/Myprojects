package com.example.restservice.model;

public enum Status {

	SUCCESS,FAILURE
}
